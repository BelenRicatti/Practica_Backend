require('rootphath')();
var usuarioBD = {};
const { query } = require('express');
const configuracion = require('config.json');
const mysql = require('mysql');

var connection = mysql.createConnection(config.database);
// conectarse a mysql
connection.connect(function (err) {
    if (err) {
        console.log(err.code);
        console.log(err.fatal);
    } else {
        console.log("Conectado");
    }
});

usuarioBD.getAll = function (funcallback) {
    var consulta = 'SELECT * from usuario';
    connection.query(consulta, function (err, rows,) {
        if (err) {
            funcallback(err);
            return
        }
        funcallback(rows);
    });
};

usuarioBD.create = function (usuario, funcallback) {
    params = [usuario.email, usuario.nickname, usuario.clave];
    consulta = 'INSERT INTO usuario (email, nickname, clave)) VALUES (?,?,?)';

    connection.query(consulta, params, (err, rows) => {
        if (err) {
            funcallback({
                message: "Surgio un error",
                detail: err
            });
        } else {
            funcallback(undefined, {
                message: "Se creo el usuario " + usuario.nickname,
                detail: rows
            });
        }
    });
}

usuarioBD.update = function (datos_usuario, id_usuario, funcallback) {
    consulta = 'UPDATE USUARIO set email = ?, contraseña = ? WHERE usuario_id = ?';
    params = [datos_usuario.email, datos_usuario.contraseña, id_usuario]
    connection.query(consulta, parametros, function (err, rows) {
        if (err) {
            res.status(500).send(err);
            return;
        } else {
            if (rows.affectedRows == 0) {
                res.status(404).send({
                    message: "No se encontro la persona " + req.params.dni,
                    detail: rows
                });
            } else {
                res.send({
                    message: "Se modifico la persona " + req.params.dni,
                    detail: rows
                });
            }
        }
    });
};


usuarioBD.delete = function (id_u_e, retorno) {
    parametros = [id_u_e];
    consulta = 'DELETE FROM usuario WHERE id_usuario = ?';

    connection.query(consulta, parametros, (err, result) => {
        if (err) {
            retorno({ menssage: err.code, detail: err }, undefined);
        } else {
            if (result.affectedRows == 0) {
                retorno(undefined, {
                    massage: "No se encontro a el usuario ",
                    detail: rows
                });
            } else {
                res.send({
                    message: "Usuario eliminado",
                    detail: rows
                });
            }
        }
    });
};

module.exports = usuarioBD;