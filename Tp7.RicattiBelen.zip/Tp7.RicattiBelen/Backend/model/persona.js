require('rootphath')();
var personaBD = {};
const { query } = require('express');
const configuracion = require('config.json');
const mysql = require('mysql');

var connection = mysql.createConnection(config.database);
// conectarse a mysql
connection.connect(function (err) {
    if (err) {
        console.log(err.code);
        console.log(err.fatal);
    } else {
        console.log("Conectado");
    }
});

personaBD.getAll = function (funcallback) {
    var consulta = 'SELECT * from persona';
    connection.query(consulta, function (err, rows,) {
        if (err) {
            funcallback(err);
            return
        }
        funcallback(rows);
    });
};

personaBD.create = function (persona, funcallback) {
    params = [persona_dni, persona_nombre, persona_apellido];
    consulta = 'INSERT INTO persona (dni, nombre, apellido)) VALUES (?,?,?)';

    connection.query(consulta, params, (err, rows) => {
        if (err) {
            funcallback({
                message: "Surgio un error",
                detail: err
            });
        } else {
            funcallback(undefined, {
                message: "Se creo la persona" + persona.nombre,
                detail: rows
            });
        }
    });
}

personaBD.update = function (persona_dni, persona_nombre, persona_apellido, funcallback) {
    consulta = 'UPDATE persona set dni = ?, nombre = ?, apellido = ? WHERE dni = ?';
    params = [persona.dni, persona.nombre, persona.apellido]
    connection.query(consulta, parametros, function (err, rows) {
        if (err) {
            res.status(500).send(err);
            return;
        } else {
            if (rows.affectedRows == 0) {
                res.status(404).send({
                    message: "No se encontro la persona " + req.params.dni,
                    detail: rows
                });
            } else {
                res.send({
                    message: "Se modifico la persona " + req.params.dni,
                    detail: rows
                });
            }
        }
    });
};

personaBD.delete = function (persona_dni, retorno) {
    parametros = [persona_dni];
    consulta = 'DELETE FROM persona WHERE dni = ?';

    connection.query(consulta, parametros, (err, result) => {
        if (err) {
            retorno({ menssage: err.code, detail: err }, undefined);
        } else {
            if (result.affectedRows == 0) {
                retorno(undefined, {
                    massage: "No se encontro a la persona ",
                    detail: rows
                });
            } else {
                res.send({
                    message: "Persona eliminada",
                    detail: rows
                });
            }
        }
    });
};

module.exports = personaBD;