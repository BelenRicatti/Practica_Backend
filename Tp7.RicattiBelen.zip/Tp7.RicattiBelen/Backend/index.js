require('rootpath')();
const express = require('express');
const morgan = require('morgan');
const app = express();  

app.use(morgan('tiny'));
morgan(':method :url :status :res[content-length] - :response-time ms')
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const configuracion = require('config.json');
const controladorPersona = require("controller/personacontroller.js");
const controladorUsuario = require("controller/usuariocontroller.js");

app.use('/api/persona', controladorPersona);
app.use('/api/usuario', controladorUsuario);

app.listen(configuracion.server.port, (err) => {
    if (err) {
        console.log(err);
    }else {
        console.log("Servidor escuchando puerto " + configuracion.server.port);
    }
});




   