require('rootpath')();
const express = require('espress');
const app = express();
const configuracion = require("config.json")
app.use(express.json());
app.use(express.urlencoded ({extended: true}));
var usuarioBD = require("model/usuario.js");


app.get('/', getAll);
app.post('/', crear);
app.put('/:dni', modificar);
app.delete('/:dni', borrar);
app.get('/:dni', getByemail);


function getAll (req, res) {
  usuarioBD.getAll((err, resultado) => {
      if(err){
           res.status(500).send(err);
        }else{
           res.json(resultado);
        }
    });
};    

function crear(req, res) {
    let usuario = req.body;
    usuarioBD.create(usuario, (err, rows) => {
        if(err){
            res.status(500).send(err);
        }else{
            res.json(rows);
        }
    });
};


function modificar(req, res) {
    let datos_usuario = req.body;
    let id_usuario = req.params
    usuarioBD.update(datos_usuario, id_usuario, (err, resultado) => {
        if(err) {
            res.status(500).send(err);
        }else {
            res.send(resultado)
        }    
    });
};

function borrar(req, res) {
    let id_u_e = req.body;
    usuarioBD.create(id_u_e, (err, rows) => {
        if(err){
            res.status(500).send(err);
        }else{
            res.json(rows);
        }
    });
   
};

function getByemail(req, res) {
    let id = req.params.email;
    usuarioBD.getByemail(id, (err, result_model) => {
        if (err) {
            res.status(500).send(err);
        }else {
            res.send(result_model);
        }
    });
};



module.exports = app;