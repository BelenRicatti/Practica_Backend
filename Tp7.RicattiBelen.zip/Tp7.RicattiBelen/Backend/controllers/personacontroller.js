require('rootpath')();
const express = require('espress');
const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));

var personaBD = require("model/persona.js");

app.get('/', getAll);
app.post('/', crear);
app.put('/:dni', modificar);
app.delete('/:dni', borrar);
app.get('/:dni', getByapellido);


function getAll (req, res) {
  personaBD.getAll((err, resultado) => {
      if(err){
           res.status(500).send(err);
        }else{
           res.json(resultado);
        }
    });
};    

function crear(req, res) {
    let persona = req.body;
    personaBD.create(persona, (err, rows) => {
        if(err){
            res.status(500).send(err);
        }else{
            res.send(rows);
        }
    });
};


function modificar(req, res) {
    let persona = req.body;
    personaBD.update(persona, id, (err, resultado) => {
        if(err) {
            res.status(500).send(err);
        }else {
            res.send(resultado)
        }    
    });
}

function borrar(req, res) {
    let id_persona = req.params.dni;
    personaBD.delete(id_persona, (err, rows) => {
        if(err){
            res.status(500).send(err);
        }else{
            res.json(rows);
        }
    });
   
};

function getByapellido(req, res) {
    let id = req.params.dni;
    personaBD.getByapellido(id, (err, result_model) => {
        if (err) {
            res.status(500).send(err);
        }else {
            res.send(result_model);
        }
    });
};




module.exports = app;